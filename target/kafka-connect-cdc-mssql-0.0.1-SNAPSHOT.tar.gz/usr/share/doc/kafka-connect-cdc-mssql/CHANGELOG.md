                                ## Unreleased
                                ### No issue

                                **Allow configuration value for MultiSubnetFailover (#7)**

                                * This allows a user to include the config value to enable MultiSubnetFailover.
                                * The slight change in the .gitignore is due to auto created files in VSCode.

                                [ae588d38c246ee6](https://github.com/jcustenborder/kafka-connect-cdc-mssql/commit/ae588d38c246ee6) Jon Vines *2018-01-12 00:01:54*

                                **Added version tag.**


                                [512027a74a4b137](https://github.com/jcustenborder/kafka-connect-cdc-mssql/commit/512027a74a4b137) Jeremy Custenborder *2017-08-10 16:06:10*

                                **Issue 1 (#3)**

                                * Remove the extra services to reduce startup time.
                                * Reduce the verbosity of reflections.
                                * Lots of cleanup. Added support for uniqueidentifiers to be treated as strings.

                                [bc4025aecc09ab5](https://github.com/jcustenborder/kafka-connect-cdc-mssql/commit/bc4025aecc09ab5) Jeremy Custenborder *2017-08-09 19:48:33*

                                **Initial commit from project breakout. (#2)**

                                * Initial commit
                                * Added jenkins
                                * Added the license file. Changed the pom to use a specific version.

                                [025c527bfd83dd7](https://github.com/jcustenborder/kafka-connect-cdc-mssql/commit/025c527bfd83dd7) Jeremy Custenborder *2017-08-09 17:03:04*


